import java.util.ArrayList;
import java.util.Scanner;


public class Task_8 {

	public static void main(String[] args) {
		
		Scanner userInput  = new Scanner (System.in);
		System.out.println("How many rows of Pascal triangle do you want?");
		int n = userInput.nextInt();
		
		userInput.close();
		
				

	}
	
	public static void pascalsTriangle( int n){
		
		ArrayList<Integer> pasc = new ArrayList<Integer>();
		pasc.add(1);
		for(int i = 0; i < n; i++){
			pasc
		}
		
	}
	

}
