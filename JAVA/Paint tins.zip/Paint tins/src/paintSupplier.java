

public class paintSupplier {

	private String brand;
	private double price;
	private double litres;
	private int coverage;
	
	public String getBrand(){
		return brand;
	}
	
	public int getCoverage(){
		return coverage;
	}
	
	public double getPrice(){
		return price;
	}
	
	public double getLitres(){
		return litres;
	}
	
	
	public paintSupplier(String mBrand, double mPrice, double mLitres, int mCoverage){
		
		brand = mBrand;
		price = mPrice;
		litres = mLitres;
		coverage = mCoverage;
		
		
	}
	
}
